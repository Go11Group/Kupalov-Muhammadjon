package model

type Grade struct{
	CourseName string
	Points int
}