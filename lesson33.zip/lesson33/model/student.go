package model

type Student struct{
	Id string
	Name string
	Age int
}

// {
// 	"name": "Jerry"
// 	"age": 19
// }